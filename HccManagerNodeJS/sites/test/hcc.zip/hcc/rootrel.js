function getRootrel(arg){
	return "rootrel.js " + arg;
}