function getRootabs(arg){
	return "rootabs.js " + arg;
}