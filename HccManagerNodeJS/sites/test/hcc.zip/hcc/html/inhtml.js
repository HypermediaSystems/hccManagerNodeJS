function getInhtml(arg){
	return "inhtml.js " + arg;
}